
public class GradStudent extends Student {

	public Double gradGPA;
	public String gradGraduationYear;
	
	GradStudent(String fName, String lName, Double ugGPA, Integer ugSchool, String gradSchool, Double gradGPA) {
	
		super(fName, lName, ugGPA, ugSchool);
		this.gradGPA= gradGPA;
		this.gradSchool = gradSchool;
	}

	public String toString() {
		String studentInfo = super.toString();
		
		return studentInfo + this.gradGPA + " "+ this.gradGraduationYear;
	}
}
