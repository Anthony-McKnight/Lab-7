
public class Student {
	public String firstName;
	public String lastName;
	public String school;
	public Double gpa;
	public Integer graduationYear;
	
	Student (String fName, String lName, String ugSchool, Double ugGPA, Integer gYear){
		this.firstName = fName;
		this.lastName= lName;
		this.school= ugSchool;
		this.gpa= ugGPA;
		this.graduationYear= gYear;
	}
	public String toString() {
		return "First Name" + this.firstName + "\n" +
			   "Last Name" + this.lastName + "\n" +
			   "UG School" + this.school + "\n" +
			   "UG GPA" + this.gpa + "\n";
		
	}
}