
public class TestInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GradStudent gs1 = new GradStudent ("Adam", "Maple", "MU", 3.55, "Monmouth", 4.0);
		System.out.print(gs1.toString());
		
		GradStudent gs2 = new GradStudent ("Saahil", "Ahmed", "MU", 3.8, "Monmouth", 4.0);
		System.out.print(gs2.toString());
		
		GradStudent gs3 = new GradStudent ("Johnny", "Appleseed", "MU", 2.3, "Monmouth", 4.0);
		System.out.print(gs3.toString());
		
		GradStudent gs4 = new GradStudent ("Sherlock", "Holmes", "MU", 4.0, "Monmouth", 4.0);
		System.out.print(gs4.toString());
	}

}
